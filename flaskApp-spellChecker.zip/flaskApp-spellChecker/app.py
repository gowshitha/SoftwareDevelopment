from flask import Flask, render_template, request

import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.corpus import words

# download necessary nltk resources
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('words')

# initialize lemmatizer
lemmatizer = WordNetLemmatizer()

# get set of english words
english_words = set(words.words())

# initialize Flask app
app = Flask(__name__)

# define a route for the index page
@app.route('/')
def index():
    return render_template('index.html')

# define a route for spell checking
@app.route('/check', methods=['POST'])
def check():
    # get text from form data
    text = request.form['text']

    # tokenize the input text
    tokens = word_tokenize(text)

    # remove stopwords from the tokens
    filtered_tokens = [token.lower() for token in tokens if token.lower() not in stopwords.words()]

    # lemmatize the filtered tokens
    lemmatized_tokens = [lemmatizer.lemmatize(token) for token in filtered_tokens]

    # perform spell checking
    misspelled = [token for token in lemmatized_tokens if token not in english_words]

    # return misspelled words
    if len(misspelled) > 0:
        return render_template('index.html', misspelled=misspelled)
    else:
        return render_template('index.html', message='No misspelled words found.')

if __name__ == '__main__':
    app.run(debug=True)
